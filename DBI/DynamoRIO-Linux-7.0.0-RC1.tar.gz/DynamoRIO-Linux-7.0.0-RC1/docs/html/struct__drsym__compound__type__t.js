var struct__drsym__compound__type__t =
[
    [ "field_types", "struct__drsym__compound__type__t.html#ad7907b39ef9c8fba3dab28d453dadad0", null ],
    [ "name", "struct__drsym__compound__type__t.html#a99fb7cacd3de931be43eebe39669f0bd", null ],
    [ "num_fields", "struct__drsym__compound__type__t.html#ae1de443ad92a05ada37b17da150f3fe5", null ]
];