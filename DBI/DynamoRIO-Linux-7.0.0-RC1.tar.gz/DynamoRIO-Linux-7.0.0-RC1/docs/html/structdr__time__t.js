var structdr__time__t =
[
    [ "day", "structdr__time__t.html#a70a80cab9ecc983aa41aac826c567a79", null ],
    [ "day_of_week", "structdr__time__t.html#a5e8ddf211fa32449578e676b9d3b7eb5", null ],
    [ "hour", "structdr__time__t.html#a652389d84463c1f8b3e1360a2b029f5c", null ],
    [ "milliseconds", "structdr__time__t.html#aaaae9289eebdfbc7868a0ec895296acb", null ],
    [ "minute", "structdr__time__t.html#a04016ce3f7f782c0b8162429ac0a29bc", null ],
    [ "month", "structdr__time__t.html#a8f7ae55fbaa6100b2f2ea1b511235030", null ],
    [ "second", "structdr__time__t.html#a2c63b61ff9664368aa999af1398e2c6c", null ],
    [ "year", "structdr__time__t.html#a200f3d9e7b728569503c5b8041883136", null ]
];