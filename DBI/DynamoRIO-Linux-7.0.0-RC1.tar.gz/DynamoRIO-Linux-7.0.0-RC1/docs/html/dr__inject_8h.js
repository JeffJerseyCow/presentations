var dr__inject_8h =
[
    [ "ERROR_IMAGE_MACHINE_TYPE_MISMATCH_EXE", "dr__inject_8h.html#a59d7d07c8ff5002b85b45d7ac21bdd51", null ],
    [ "WARN_IMAGE_MACHINE_TYPE_MISMATCH_EXE", "dr__inject_8h.html#a7e904aca534e09fccc4502dcc9ca5193", null ],
    [ "dr_inject_get_image_name", "dr__inject_8h.html#aac52fbcd5daed793a91a7903f393086f", null ],
    [ "dr_inject_get_process_handle", "dr__inject_8h.html#ac93f0d554f2ae003ba97e3aa5815eb2a", null ],
    [ "dr_inject_get_process_id", "dr__inject_8h.html#a953a5604db5cb8570b063b6a95764044", null ],
    [ "dr_inject_prepare_new_process_group", "dr__inject_8h.html#a6c45ee5291880dce2c26e06233c02a03", null ],
    [ "dr_inject_prepare_to_exec", "dr__inject_8h.html#a4acf52ec4bc354ad729dd7e580e5ffb0", null ],
    [ "dr_inject_prepare_to_ptrace", "dr__inject_8h.html#aac318714936b1f01498cd28f4718d0fc", null ],
    [ "dr_inject_print_stats", "dr__inject_8h.html#ade6be04e498ae27d72d15b00314ed230", null ],
    [ "dr_inject_process_create", "dr__inject_8h.html#a77b0c082257a96deebb67ad23f381426", null ],
    [ "dr_inject_process_exit", "dr__inject_8h.html#afdd617e9fd2f5876fdaa63c27839c6de", null ],
    [ "dr_inject_process_inject", "dr__inject_8h.html#ab2a383d92917deebddd8c5ce2d80ea12", null ],
    [ "dr_inject_process_run", "dr__inject_8h.html#a2cb96f6575ec364703c228667a9cc2be", null ],
    [ "dr_inject_wait_for_child", "dr__inject_8h.html#afe7492fc543a3e395af4c6de7846ee43", null ]
];