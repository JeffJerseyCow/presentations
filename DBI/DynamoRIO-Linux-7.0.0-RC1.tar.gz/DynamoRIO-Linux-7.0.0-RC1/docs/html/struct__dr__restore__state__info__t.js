var struct__dr__restore__state__info__t =
[
    [ "fragment_info", "struct__dr__restore__state__info__t.html#a2e1ca2ab722a29dc4f8b55129a5056ae", null ],
    [ "mcontext", "struct__dr__restore__state__info__t.html#a934e7d096e01de891ff4a52b88842bff", null ],
    [ "raw_mcontext", "struct__dr__restore__state__info__t.html#ab67531ba6dcb92c1c987ee980a2e6fc3", null ],
    [ "raw_mcontext_valid", "struct__dr__restore__state__info__t.html#a32a49b904d837fdd417fd07c13c8d4b4", null ]
];