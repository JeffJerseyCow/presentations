var struct__drreg__options__t =
[
    [ "conservative", "struct__drreg__options__t.html#a3f7789278b96170f6b9345c6bec730b8", null ],
    [ "do_not_sum_slots", "struct__drreg__options__t.html#a24b28e18148dfa38d91994024319ebe9", null ],
    [ "error_callback", "struct__drreg__options__t.html#a3a290ce7be16fe495f0c7bb521764e44", null ],
    [ "num_spill_slots", "struct__drreg__options__t.html#a6bbbd6b9f361d671cec4c6bd0142259d", null ],
    [ "struct_size", "struct__drreg__options__t.html#a8bc71c47c70c0ac240cb6c75822f619d", null ]
];