var dr__api_8h =
[
    [ "dr_client_main", "dr__api_8h.html#a2b938c98dd186cc94eef6880f9e3c3e9", null ],
    [ "dr_init", "dr__api_8h.html#a819eb581527829240bf227d5a8f98e4c", null ]
];