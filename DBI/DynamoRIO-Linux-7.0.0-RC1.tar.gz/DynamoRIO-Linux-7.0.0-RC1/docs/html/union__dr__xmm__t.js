var union__dr__xmm__t =
[
    [ "reg", "union__dr__xmm__t.html#ae2bc4ab082c64cb3692c154d0565044f", null ],
    [ "u32", "union__dr__xmm__t.html#af0a46f92c051370505616885810d9e71", null ],
    [ "u64", "union__dr__xmm__t.html#a31e767d50402a3da7879062840e2a787", null ],
    [ "u8", "union__dr__xmm__t.html#a4de211ec7f13bd2daea07a1675f34ce2", null ]
];