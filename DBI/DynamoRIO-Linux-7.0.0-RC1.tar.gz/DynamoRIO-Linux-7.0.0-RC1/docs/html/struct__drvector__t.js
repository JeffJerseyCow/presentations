var struct__drvector__t =
[
    [ "array", "struct__drvector__t.html#a5c9bec5511cdff545bd57359e89d28e6", null ],
    [ "capacity", "struct__drvector__t.html#ab7d8d7a51745a133c587c8b5a3dc0710", null ],
    [ "entries", "struct__drvector__t.html#ac477b5fe208fbc26774954584107cc97", null ],
    [ "free_data_func", "struct__drvector__t.html#aeaf30d5a2eb34f62af43be996ca7e38d", null ],
    [ "lock", "struct__drvector__t.html#afc85faf9469e92cb4cf9af6ef1b0cccd", null ],
    [ "synch", "struct__drvector__t.html#ab8cec435798346692a19ec474c853f1d", null ]
];