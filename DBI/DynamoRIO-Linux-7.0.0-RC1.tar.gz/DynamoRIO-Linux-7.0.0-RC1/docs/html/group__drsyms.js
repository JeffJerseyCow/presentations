var group__drsyms =
[
    [ "_drsym_info_t", "struct__drsym__info__t.html", [
      [ "debug_kind", "struct__drsym__info__t.html#adbd133ae45032c28104876fcd32c0f96", null ],
      [ "end_offs", "struct__drsym__info__t.html#a1eaa35cd0361270888d92aec79c72a20", null ],
      [ "file", "struct__drsym__info__t.html#a41e7edd37b30dc6bee532788d36d4729", null ],
      [ "file_available_size", "struct__drsym__info__t.html#a2e0a7c0b2e1e9aaccce37c84f06e26cb", null ],
      [ "file_size", "struct__drsym__info__t.html#a480117e58d4baf4d666410eace77b888", null ],
      [ "flags", "struct__drsym__info__t.html#accaf16647311e68626f41be371c02c4b", null ],
      [ "line", "struct__drsym__info__t.html#aaa74a4e9b5a672f2c2b8f6a375ae4602", null ],
      [ "line_offs", "struct__drsym__info__t.html#ae05de8b3cf18dfc8b3229342f66bfd05", null ],
      [ "name", "struct__drsym__info__t.html#aef01d2677a26a79cff6377a3f6b50e50", null ],
      [ "name_available_size", "struct__drsym__info__t.html#a15ac5858b237e551d5dac7ac56c2a759", null ],
      [ "name_size", "struct__drsym__info__t.html#a3062bd7f287e4ff235af1e3aae2be39c", null ],
      [ "start_offs", "struct__drsym__info__t.html#a8c9fda578d6fd6a60ebb20847b561bbd", null ],
      [ "struct_size", "struct__drsym__info__t.html#acd54e31710d366097dcbf2984cf337c5", null ],
      [ "type_id", "struct__drsym__info__t.html#aa195f8c0a085206d0af8fbc04fb311b9", null ]
    ] ],
    [ "_drsym_type_t", "struct__drsym__type__t.html", [
      [ "id", "struct__drsym__type__t.html#a38a5c7f88aeacdcc4922f174cf91f881", null ],
      [ "kind", "struct__drsym__type__t.html#a0479a9de2e581fe69cf6b800cd68de1d", null ],
      [ "size", "struct__drsym__type__t.html#a14e2d3815493d4aa393f514e8704d1ed", null ]
    ] ],
    [ "_drsym_func_type_t", "struct__drsym__func__type__t.html", [
      [ "arg_types", "struct__drsym__func__type__t.html#a3b9b4a4bd1de820c8da721f8e94714e1", null ],
      [ "num_args", "struct__drsym__func__type__t.html#a7cfa345c4e5ef43950432d096e36320c", null ]
    ] ],
    [ "_drsym_compound_type_t", "struct__drsym__compound__type__t.html", [
      [ "field_types", "struct__drsym__compound__type__t.html#ad7907b39ef9c8fba3dab28d453dadad0", null ],
      [ "name", "struct__drsym__compound__type__t.html#a99fb7cacd3de931be43eebe39669f0bd", null ],
      [ "num_fields", "struct__drsym__compound__type__t.html#ae1de443ad92a05ada37b17da150f3fe5", null ]
    ] ],
    [ "_drsym_int_type_t", "struct__drsym__int__type__t.html", null ],
    [ "_drsym_ptr_type_t", "struct__drsym__ptr__type__t.html", null ],
    [ "_drsym_line_info_t", "struct__drsym__line__info__t.html", [
      [ "cu_name", "struct__drsym__line__info__t.html#aae0d10af3098d126dbfa56763aea6d6f", null ],
      [ "file", "struct__drsym__line__info__t.html#a42a34d0ac23bf1ec0a841e73e30617a5", null ],
      [ "line", "struct__drsym__line__info__t.html#ad0be9544621e4d215b36248fb861d3a1", null ],
      [ "line_addr", "struct__drsym__line__info__t.html#aeda9057ec8fb963a9611e670ce399d6b", null ]
    ] ],
    [ "drsym_compound_type_t", "group__drsyms.html#gae601868c425dd7db2c7450014f1f47b5", null ],
    [ "drsym_enumerate_cb", "group__drsyms.html#ga0efead709c38c583b79a06a78786199f", null ],
    [ "drsym_enumerate_ex_cb", "group__drsyms.html#ga99f1dff00e16a4abd4993590f337a21c", null ],
    [ "drsym_enumerate_lines_cb", "group__drsyms.html#gafa1e3dc644f4c77f785d95514870525a", null ],
    [ "drsym_func_type_t", "group__drsyms.html#ga3de06a92ea1be03694869f4f38045938", null ],
    [ "drsym_info_t", "group__drsyms.html#gac7ae60d7c499c017414574b22d6d4879", null ],
    [ "drsym_int_type_t", "group__drsyms.html#ga9075a62cb47f48762911d8cd7c683035", null ],
    [ "drsym_line_info_t", "group__drsyms.html#ga1970a3bc66539e8187ee33c1ce5338e7", null ],
    [ "drsym_ptr_type_t", "group__drsyms.html#ga6536ad3236ff3d06eeeaf1450cb77b79", null ],
    [ "drsym_type_t", "group__drsyms.html#ga75abd525d4d1710196d18d7c13b4c061", [
      [ "DRSYM_TYPE_OTHER", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53a3df07cfcbf3fcb8e0e203d844421c8f3", null ],
      [ "DRSYM_TYPE_INT", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53ac4568bd915a95c4f2e641c593171ad14", null ],
      [ "DRSYM_TYPE_PTR", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53a038a317ac51c1ee78f6b85a1ad220d83", null ],
      [ "DRSYM_TYPE_FUNC", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53ad608c508bb62b4ba8303fd66210e7481", null ],
      [ "DRSYM_TYPE_VOID", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53a6e6814cbb29a891671ca7047d49f1e1b", null ],
      [ "DRSYM_TYPE_COMPOUND", "group__drsyms.html#ggab48899087cc647f0f791ed0c459adc53a0967e981148150fd3c30468ec047e8aa", null ]
    ] ],
    [ "drsym_debug_kind_t", "group__drsyms.html#gad3772ffd6c4e0d68738a31d7e25a3de9", [
      [ "DRSYM_SYMBOLS", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9a3906510b7b336284f72153a9c17127b0", null ],
      [ "DRSYM_LINE_NUMS", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9aed224abfe6e8297c7ac7bed97efda8c4", null ],
      [ "DRSYM_ELF_SYMTAB", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9af9680fa1e5316576914fd50d253016da", null ],
      [ "DRSYM_DWARF_LINE", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9a114c2a44936aced9bbacc28a3916544c", null ],
      [ "DRSYM_PDB", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9a32b1e745d5eb1a730c12f2b2ed973168", null ],
      [ "DRSYM_PECOFF_SYMTAB", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9a0ef6cab1fee912683e2c99498492979b", null ],
      [ "DRSYM_MACHO_SYMTAB", "group__drsyms.html#ggad3772ffd6c4e0d68738a31d7e25a3de9a2a707a29f9e542d4f8f980b3a2cdaafe", null ]
    ] ],
    [ "drsym_error_t", "group__drsyms.html#ga78793b36b5a0f529fb746b7ed0072442", [
      [ "DRSYM_SUCCESS", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442a3b3ded5e053b03dd0dde640a2157a7da", null ],
      [ "DRSYM_ERROR", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442a2fc0cc43fc4976260bca5fa948a5e2a5", null ],
      [ "DRSYM_ERROR_INVALID_PARAMETER", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442acff4fa6815bc58797d18faa9a009ac60", null ],
      [ "DRSYM_ERROR_INVALID_SIZE", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442ae263ac8a135526a666647874f2a32aac", null ],
      [ "DRSYM_ERROR_LOAD_FAILED", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442ab1f7615ed26be43741ca64a19a228df9", null ],
      [ "DRSYM_ERROR_SYMBOL_NOT_FOUND", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442a7f8fdc7d8da1402cdcd770983dee1da1", null ],
      [ "DRSYM_ERROR_LINE_NOT_AVAILABLE", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442af631dcc99434b8d60a763b751f735db3", null ],
      [ "DRSYM_ERROR_NOT_IMPLEMENTED", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442aba1d3dbb8ee3bb78b3c921300eefa21a", null ],
      [ "DRSYM_ERROR_FEATURE_NOT_AVAILABLE", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442a0de481dcf671e55ee1c01993bc204d7a", null ],
      [ "DRSYM_ERROR_NOMEM", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442aa0b083a538144f834aca12b71cc45652", null ],
      [ "DRSYM_ERROR_RECURSIVE", "group__drsyms.html#gga78793b36b5a0f529fb746b7ed0072442a779dfcdf51f4816da44d8b291fdc008d", null ]
    ] ],
    [ "drsym_flags_t", "group__drsyms.html#ga0b67aaba18a6215dfc1ff4c68b57d41e", [
      [ "DRSYM_LEAVE_MANGLED", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41eaaa4ed2e3efae09a5a43cc303e10a89ba", null ],
      [ "DRSYM_DEMANGLE", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41ea85d6e34c4fcb68eb97a07774102c4b0e", null ],
      [ "DRSYM_DEMANGLE_FULL", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41ea926400b119322cf478117df1a074c6dc", null ],
      [ "DRSYM_DEMANGLE_PDB_TEMPLATES", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41eaf5d562cfc61f955bb16455e199dc167e", null ],
      [ "DRSYM_FULL_SEARCH", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41ea551ab826d0640b71183cea1115c697cf", null ],
      [ "DRSYM_DEFAULT_FLAGS", "group__drsyms.html#gga0b67aaba18a6215dfc1ff4c68b57d41ea2df0aa90a6e81681503326e2d8471703", null ]
    ] ],
    [ "drsym_demangle_symbol", "group__drsyms.html#gad582a65dc1308335633e0c451035dbe0", null ],
    [ "drsym_enumerate_lines", "group__drsyms.html#ga01b46346170fbc4580d2e4fb5c4ba616", null ],
    [ "drsym_enumerate_symbols", "group__drsyms.html#ga260c78496165b54b9a97d0a5e1f6f4d8", null ],
    [ "drsym_enumerate_symbols_ex", "group__drsyms.html#gad883ab113dd57f77db0c279de2c055f8", null ],
    [ "drsym_exit", "group__drsyms.html#ga5d70a336713dd08ebe256c2eb964d3ae", null ],
    [ "drsym_expand_type", "group__drsyms.html#ga211ebdc7a540e7894a741aac8b2fc808", null ],
    [ "drsym_free_resources", "group__drsyms.html#gaf3fc654dfbb2d1e1717ee60229d7ac9f", null ],
    [ "drsym_get_func_type", "group__drsyms.html#ga676bf63e860bca8a8eb3a7fe7e0dfa00", null ],
    [ "drsym_get_module_debug_kind", "group__drsyms.html#ga8b7f688e703f8ca1937f091f53d3d697", null ],
    [ "drsym_get_type", "group__drsyms.html#ga6b5e419be145c6956e796dbf3da1678d", null ],
    [ "drsym_get_type_by_name", "group__drsyms.html#gaa2e78185f942918db88c1cc249aa656b", null ],
    [ "drsym_init", "group__drsyms.html#ga8f826a91db73acb16acb6649d26a86cd", null ],
    [ "drsym_lookup_address", "group__drsyms.html#ga201e8a9bf6746cbfd232bc4e4a243d2b", null ],
    [ "drsym_lookup_symbol", "group__drsyms.html#ga2e6f4d91b65fc835c047c8ca23c83d06", null ],
    [ "drsym_module_has_symbols", "group__drsyms.html#ga88e18dc10941953589e1023d61ba0a57", null ],
    [ "drsym_search_symbols", "group__drsyms.html#gad6eb2e2cee8fba5ee6eb439905b3ecb9", null ],
    [ "drsym_search_symbols_ex", "group__drsyms.html#ga5a983d39217af0f8a39868c66e0646d0", null ]
];