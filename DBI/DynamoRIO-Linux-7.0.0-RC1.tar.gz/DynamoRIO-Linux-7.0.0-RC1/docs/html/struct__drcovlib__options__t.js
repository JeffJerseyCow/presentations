var struct__drcovlib__options__t =
[
    [ "flags", "struct__drcovlib__options__t.html#a115202269269937e8f52f5da2b6d1fe5", null ],
    [ "logdir", "struct__drcovlib__options__t.html#a782e713d7cf9e6beae1cc1b24acb19cb", null ],
    [ "native_until_thread", "struct__drcovlib__options__t.html#a76b749bcf718175e13921a95297b16f0", null ],
    [ "struct_size", "struct__drcovlib__options__t.html#a8c24d4cddc7478734b0ee84ea0c23552", null ]
];