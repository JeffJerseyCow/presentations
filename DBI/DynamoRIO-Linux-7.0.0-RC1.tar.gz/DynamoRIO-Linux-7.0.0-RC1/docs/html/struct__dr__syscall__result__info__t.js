var struct__dr__syscall__result__info__t =
[
    [ "errno_value", "struct__dr__syscall__result__info__t.html#abf54b7a452b011912d6b7bbba7b84a20", null ],
    [ "high", "struct__dr__syscall__result__info__t.html#ac48039fe12a1261d673b0a073bb7b636", null ],
    [ "size", "struct__dr__syscall__result__info__t.html#ab8762d7cd2453f6f306ee23420a9d0bd", null ],
    [ "succeeded", "struct__dr__syscall__result__info__t.html#a3865013d8cf81ac4543f02ac458de866", null ],
    [ "use_errno", "struct__dr__syscall__result__info__t.html#a08c70526e7a3c63954234021129c1a90", null ],
    [ "use_high", "struct__dr__syscall__result__info__t.html#a640d68c87a33d04d70f5680c845c5eae", null ],
    [ "value", "struct__dr__syscall__result__info__t.html#a4f3fef7d8e374b0ba9f0926d8e8fa3ec", null ]
];