var API_tutorial =
[
    [ "average_bb_size", "API_tutorial_bbdynsize1.html", "API_tutorial_bbdynsize1" ],
    [ "steal_reg", "API_tutorial_steal_reg1.html", null ],
    [ "prefetch", "API_tutorial_prefetch1.html", null ],
    [ "create_annotation", "API_tutorial_annotation1.html", "API_tutorial_annotation1" ]
];