var struct__dr__os__version__info__t =
[
    [ "service_pack_major", "struct__dr__os__version__info__t.html#a08f07ca7af394b040a62d3bf01d77f6e", null ],
    [ "service_pack_minor", "struct__dr__os__version__info__t.html#a341b994481f92f629c9f664564d5d06d", null ],
    [ "size", "struct__dr__os__version__info__t.html#aa5a6a7981e8b5a368bbd15d5b910051d", null ],
    [ "version", "struct__dr__os__version__info__t.html#a922ca431c88fcc0aab87da9a2b44ac91", null ]
];