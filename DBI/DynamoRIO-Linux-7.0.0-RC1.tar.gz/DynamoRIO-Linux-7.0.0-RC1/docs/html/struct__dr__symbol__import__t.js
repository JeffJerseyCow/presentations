var struct__dr__symbol__import__t =
[
    [ "by_ordinal", "struct__dr__symbol__import__t.html#a342f115683f37868c759f59669fe96eb", null ],
    [ "delay_load", "struct__dr__symbol__import__t.html#a02cca6354e58022daac6554b7c4938c4", null ],
    [ "modname", "struct__dr__symbol__import__t.html#a2a4ff46940de81e12edb401d68e99237", null ],
    [ "name", "struct__dr__symbol__import__t.html#a9b964c2a8e1e5627151c52033c9b2bc8", null ],
    [ "ordinal", "struct__dr__symbol__import__t.html#a5bb017f3f50671c289124207bdc47b62", null ]
];