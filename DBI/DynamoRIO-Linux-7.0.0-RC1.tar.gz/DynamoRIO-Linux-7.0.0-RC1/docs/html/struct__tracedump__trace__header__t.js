var struct__tracedump__trace__header__t =
[
    [ "cache_start_pc", "struct__tracedump__trace__header__t.html#acee4f7ed9a7342c450528e474db735b9", null ],
    [ "code_size", "struct__tracedump__trace__header__t.html#a4fc579d6044077a7168a8dca4320740e", null ],
    [ "entry_offs", "struct__tracedump__trace__header__t.html#aa4261e215e08f603687df3a6f1b4da3a", null ],
    [ "frag_id", "struct__tracedump__trace__header__t.html#a0069848dd0d2a256c5f3e6cc8db5ed6a", null ],
    [ "num_bbs", "struct__tracedump__trace__header__t.html#a6595e0ffb69d2afec5e5364e1ff3eb4a", null ],
    [ "num_exits", "struct__tracedump__trace__header__t.html#ad84faf4cf37f7087ec297b09d18610a1", null ],
    [ "tag", "struct__tracedump__trace__header__t.html#a40b61b06f139519aeed4463e66e0aa15", null ],
    [ "x64", "struct__tracedump__trace__header__t.html#a4d86106601cee1e949cc2e885c9fc8af", null ]
];