var searchData=
[
  ['access_5faddress',['access_address',['../struct__drfuzz__fault__t.html#a621eeceae7b2f2b36f682cbc932f4ef2',1,'_drfuzz_fault_t']]],
  ['analyze_5funknown_5fsyscalls',['analyze_unknown_syscalls',['../struct__drsys__options__t.html#a98bced7cd4296b8074f922cc529e9e3a',1,'_drsys_options_t']]],
  ['app_5fbase',['app_base',['../struct__umbra__shadow__memory__info__t.html#a88b0d289e81fc0977c6d91f46ec7ea3f',1,'_umbra_shadow_memory_info_t']]],
  ['app_5fmemory_5fcreate_5fcb',['app_memory_create_cb',['../struct__umbra__map__options__t.html#a9886fb5b988987a4918a61464bb85b2a',1,'_umbra_map_options_t']]],
  ['app_5fmemory_5fmremap_5fcb',['app_memory_mremap_cb',['../struct__umbra__map__options__t.html#ae61776cf0d015757e3c84a68fd33d3e1',1,'_umbra_map_options_t']]],
  ['app_5fmemory_5fpost_5fdelete_5fcb',['app_memory_post_delete_cb',['../struct__umbra__map__options__t.html#a1ebeed9022c5c8980df16b08bf838b3d',1,'_umbra_map_options_t']]],
  ['app_5fmemory_5fpre_5fdelete_5fcb',['app_memory_pre_delete_cb',['../struct__umbra__map__options__t.html#a404a50e702bafcb14fdc33084aeebdef',1,'_umbra_map_options_t']]],
  ['app_5fsize',['app_size',['../struct__umbra__shadow__memory__info__t.html#ab60f038191d648429beec20da4bf40c7',1,'_umbra_shadow_memory_info_t']]],
  ['arg_5fname',['arg_name',['../struct__drsys__arg__t.html#a91e5e2739f229d89cb9b9463f6d24000',1,'_drsys_arg_t']]]
];
