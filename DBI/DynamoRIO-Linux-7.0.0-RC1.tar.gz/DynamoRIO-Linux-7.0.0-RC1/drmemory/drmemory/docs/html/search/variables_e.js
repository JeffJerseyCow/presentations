var searchData=
[
  ['user_5fdata',['user_data',['../struct__drfuzz__fault__t.html#a4a922b5d3a0ea99e43e52fbfaa99217b',1,'_drfuzz_fault_t']]]
];
