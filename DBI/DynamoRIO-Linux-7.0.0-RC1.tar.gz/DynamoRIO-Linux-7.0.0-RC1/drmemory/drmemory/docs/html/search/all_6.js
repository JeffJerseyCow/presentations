var searchData=
[
  ['gdi_20usage_20errors',['GDI Usage Errors',['../page_gdi.html',1,'page_types']]]
];
