var searchData=
[
  ['error_20reports',['Error Reports',['../page_reports.html',1,'']]],
  ['error_20types_20reported_20by_20dr_2e_20memory',['Error Types Reported by Dr. Memory',['../page_types.html',1,'']]]
];
