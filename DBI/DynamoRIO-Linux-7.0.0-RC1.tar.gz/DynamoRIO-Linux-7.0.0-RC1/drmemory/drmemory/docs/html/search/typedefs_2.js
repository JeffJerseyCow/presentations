var searchData=
[
  ['shadow_5fiterate_5ffunc_5ft',['shadow_iterate_func_t',['../group__umbra.html#ga2aa58774b9ee9f296b953695c9db57d5',1,'umbra.h']]]
];
