var searchData=
[
  ['umbra_5fmap_5fflags_5ft',['umbra_map_flags_t',['../group__umbra.html#gaaa9d16970f73407af0af6b173afd62b6',1,'umbra.h']]],
  ['umbra_5fmap_5fscale_5ft',['umbra_map_scale_t',['../group__umbra.html#ga670274c9cd812c91317125c7179cb15a',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5fflags_5ft',['umbra_shadow_memory_flags_t',['../group__umbra.html#gaa49d0c1fffdb93fdfd0db1278b1eaad9',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5ft',['umbra_shadow_memory_type_t',['../group__umbra.html#ga218086740fc30ca9ec82ad9e1a8f94d0',1,'umbra.h']]]
];
