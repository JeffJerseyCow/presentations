var searchData=
[
  ['memory_20leaks',['Memory Leaks',['../page_leaks.html',1,'page_types']]]
];
