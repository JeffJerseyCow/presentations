var searchData=
[
  ['enum_5fname',['enum_name',['../struct__drsys__arg__t.html#ad92b8d14723ed4cc2074a8c3248f8946',1,'_drsys_arg_t']]],
  ['error_20reports',['Error Reports',['../page_reports.html',1,'']]],
  ['error_20types_20reported_20by_20dr_2e_20memory',['Error Types Reported by Dr. Memory',['../page_types.html',1,'']]]
];
