var searchData=
[
  ['umbra_3a_20dynamorio_20shadow_20memory_20extension',['Umbra: DynamoRIO Shadow Memory Extension',['../group__umbra.html',1,'']]]
];
