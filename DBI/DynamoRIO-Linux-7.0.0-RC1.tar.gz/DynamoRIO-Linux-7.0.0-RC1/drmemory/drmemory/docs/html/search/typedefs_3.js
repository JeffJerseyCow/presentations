var searchData=
[
  ['umbra_5fmap_5foptions_5ft',['umbra_map_options_t',['../group__umbra.html#ga751e3c1aba75904b324a3ad41665868f',1,'umbra.h']]],
  ['umbra_5fmap_5ft',['umbra_map_t',['../group__umbra.html#gad20b7206ae18024a3a7b1ae23b71f196',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5finfo_5ft',['umbra_shadow_memory_info_t',['../group__umbra.html#ga1b719e93a8011f4976720d37e6657d79',1,'umbra.h']]]
];
