var page_types =
[
    [ "Unaddressable Access", "page_unaddr.html", null ],
    [ "Uninitialized Read", "page_uninit.html", null ],
    [ "Invalid Heap Argument", "page_invarg.html", null ],
    [ "Memory Leaks", "page_leaks.html", null ],
    [ "GDI Usage Errors", "page_gdi.html", null ],
    [ "Handle Leaks", "page_handle.html", null ],
    [ "Warning", "page_warning.html", null ]
];