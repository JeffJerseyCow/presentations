var annotated_dup =
[
    [ "_drfuzz_crash_state_t", "struct__drfuzz__crash__state__t.html", "struct__drfuzz__crash__state__t" ],
    [ "_drfuzz_fault_t", "struct__drfuzz__fault__t.html", "struct__drfuzz__fault__t" ],
    [ "_drfuzz_fault_thread_state_t", "struct__drfuzz__fault__thread__state__t.html", "struct__drfuzz__fault__thread__state__t" ],
    [ "_drfuzz_target_frame_t", "struct__drfuzz__target__frame__t.html", null ],
    [ "_drsys_arg_t", "struct__drsys__arg__t.html", "struct__drsys__arg__t" ],
    [ "_drsys_options_t", "struct__drsys__options__t.html", "struct__drsys__options__t" ],
    [ "_drsys_sysnum_t", "struct__drsys__sysnum__t.html", "struct__drsys__sysnum__t" ],
    [ "_umbra_map_options_t", "struct__umbra__map__options__t.html", "struct__umbra__map__options__t" ],
    [ "_umbra_shadow_memory_info_t", "struct__umbra__shadow__memory__info__t.html", "struct__umbra__shadow__memory__info__t" ]
];