Default destination for DynamoRIO log files (for diagnostics only).
